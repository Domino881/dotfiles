---

Created by David Forrester, borrowing heavily from the work of kiwidude.
It is currently maintained by Jan Larres.

Calibre officially distributes plugins from the mobileread.com forum site.
The official distro channel for this plugin is there: [Kobo Utilities](https://www.mobileread.com/forums/showthread.php?t=366110)

The source for this plugin is available on [GitHub](https://github.com/majutsushi/kobo-utilities).
